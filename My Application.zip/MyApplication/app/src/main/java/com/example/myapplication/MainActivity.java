package com.example.myapplication;

import android.os.Bundle;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.TextView;

import androidx.appcompat.app.AppCompatActivity;

public class MainActivity extends AppCompatActivity {
    CheckBox arroz, leite, carne, feijao, refrigerante;
    Button btnCalcular;
    TextView textTotal;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        arroz = findViewById(R.id.checkArroz);
        leite = findViewById(R.id.checkLeite);
        carne = findViewById(R.id.checkCarne);
        feijao = findViewById(R.id.checkFeijao);
        refrigerante = findViewById(R.id.checkRefrigerante);
        btnCalcular = findViewById(R.id.btnCalcular);
        textTotal = findViewById(R.id.textTotal);

        btnCalcular.setOnClickListener(v -> {
            double total = 0.0;
            if (arroz.isChecked()) total += 2.69;
            if (leite.isChecked()) total += 2.70;
            if (carne.isChecked()) total += 16.70;
            if (feijao.isChecked()) total += 3.38;
            if (refrigerante.isChecked()) total += 3.00;
            textTotal.setText(String.format("Total: R$ %.2f", total));
        });
    }
}



